# Covid 19 Project Backend

This is API for Covid 19. Built with Spring Boot.

For documentation, go to /docs.html (Recommended) or /swagger-ui.html.
