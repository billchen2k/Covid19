package com.covid19.backend;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.util.List;
import java.util.Map;

@SpringBootTest
class BackendApplicationTests {


	@Test
	void myTest() {

		System.out.println("Hi");

	}


	@Test
	void myTest2() {

		System.out.println("Hi2");

	}


}
