<template>

</template>

<script>

  /** Allow Credentials Globally **/
  export default {
    name: 'config',
    // apiurl: 'http://8.210.248.203'
    apiurl: 'https://covid19api.billc.io'
    // apiurl: 'http://45.76.79.85'
    // apiurl: 'http://localhost'
  }
</script>

<style scoped>

</style>
