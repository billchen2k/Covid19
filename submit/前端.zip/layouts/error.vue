<template>
  <div class="Error">
    <h1 class="Error-Heading">
      {{ headingTitle }}
    </h1>
    <div class="Error-BodyContainer">
      <p class="Error-Body">
        {{ $t('アクセスしようとしたページが見つかりませんでした。') }}<br />
        {{
          $t(
            'ページが移動または削除されたか、URLの入力間違いの可能性があります。'
          )
        }}
      </p>
      <div class="Error-ButtonContainer">
        <NuxtLink :to="localePath('/')" class="Error-Button">
          {{ $t('トップページへ戻る') }}
        </NuxtLink>
      </div>
    </div>
  </div>
</template>

<i18n>
{
  "ja": {
    "このページはご利用いただけません": "このページはご利用いただけません",
    "現在ご利用できません": "現在ご利用できません",
    "アクセスしようとしたページが見つかりませんでした。": "アクセスしようとしたページが見つかりませんでした。",
    "ページが移動または削除されたか、URLの入力間違いの可能性があります。": "ページが移動または削除されたか、URLの入力間違いの可能性があります。",
    "トップページへ戻る": "トップページへ戻る"
  },
  "en": {
    "このページはご利用いただけません": "This page is unavailable.",
    "現在ご利用できません": "It's currently unavailable.",
    "アクセスしようとしたページが見つかりませんでした。": "The page you tried to access could not be found.",
    "ページが移動または削除されたか、URLの入力間違いの可能性があります。": "The page may have been moved or deleted, or you might have typed the wrong URL.",
    "トップページへ戻る": "Back to top page."
  },
  "zh-cn": {
    "このページはご利用いただけません": "您访问的页面无法使用。",
    "現在ご利用できません": "目前暂时无法使用。",
    "アクセスしようとしたページが見つかりませんでした。": "您访问的页面不存在。",
    "ページが移動または削除されたか、URLの入力間違いの可能性があります。": "您访问的页面可能已经被删除或者更名，请检查您输入的网址是否正确。",
    "トップページへ戻る": "回到首页"
  },
  "zh-tw": {
    "このページはご利用いただけません": "這個網頁無法使用。",
    "現在ご利用できません": "現在無法使用。",
    "アクセスしようとしたページが見つかりませんでした。": "您找的網頁目前沒有找到。",
    "ページが移動または削除されたか、URLの入力間違いの可能性があります。": "該網頁可能被移動或是刪除了，或是您有可能輸入了錯誤的網址。",
    "トップページへ戻る": "回到首頁"
  },
  "ko": {
    "このページはご利用いただけません": "이 페이지는 이용할 수 없습니다.",
    "現在ご利用できません": "현재 이용할 수 없습니다.",
    "アクセスしようとしたページが見つかりませんでした。": "접속하려고 한 페이지를 찾을 수 없습니다.",
    "ページが移動または削除されたか、URLの入力間違いの可能性があります。": "페이지가 이동되거나, 삭제되었거나, URL의 입력이 잘못되었을 가능성이 있습니다.",
    "トップページへ戻る": "위로 돌아가기"
  },
  "ja-basic": {
    "このページはご利用いただけません": "このページはつかえません",
    "現在ご利用できません": "いま このページはつかえません",
    "アクセスしようとしたページが見つかりませんでした。": "このページはありませんでした",
    "ページが移動または削除されたか、URLの入力間違いの可能性があります。": "ページがなくなったか いれたものがちがっています",
    "トップページへ戻る": "はじめのページにもどる"
  }
}
</i18n>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  layout: 'empty',
  props: {
    error: {
      type: Object,
      default: null
    }
  },
  computed: {
    isNotFound(): boolean {
      return this.error.statusCode === 404
    },
    headingTitle(): string {
      return this.isNotFound
        ? (this.$t('このページはご利用いただけません') as string)
        : (this.$t('現在ご利用できません') as string)
    }
  }
})
</script>

<style lang="scss" scoped>
.Error {
  &-Heading {
    @include font-size(30);
    color: $gray-2;
    font-weight: normal;
    margin-top: 28px;
    @include lessThan($small) {
      margin-top: 12px;
    }
  }
  &-BodyContainer {
    margin-top: 12px;
    @include card-container();
    padding: 20px;
  }
  &-Body {
    @include body-text();
  }
  &-ButtonContainer {
    margin-top: 24px;
    text-align: center;
  }
  &-Button {
    @include button-text('md');
    text-decoration: none;
    max-width: 300px;
    width: 100%;
    font-weight: bold;
  }
}
</style>
