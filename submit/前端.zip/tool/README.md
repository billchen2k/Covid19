# Need

- php 7.x
- composer

# Usage

- download source xlsx files to `downloads` dir
- composer install
- php convert.php
- will be update data.json to {project_dir}/data/data.json

